package unitTests;

public class EditAvailabilityTest {

}
