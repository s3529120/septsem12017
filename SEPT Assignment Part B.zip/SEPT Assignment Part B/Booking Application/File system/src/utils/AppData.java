package utils;

import Model.AccountModel;

public class AppData {
	public static AccountModel CALLER;
}
