SEPT Assignment Part B

Team Members

Thomas Higgins - s3529120
Declan McDonald - s3488797
Jasmine Ellis - s3449107
Robert Laine-Wyllie - s3433096


Tutorial

Amir Homayoon Ashrafzadeh
Friday 12:30 - 2:30 PM


Peer Assessment

Thomas Higgins - 34%
Lead Developer
 - Service functionality
 - Specialisation functionality
 - Booking type assignment
 - Booking customer assignment
 - Dashboard implementation
 - Base GUI elements for above functions
 - Logging implementation
 - Class diagram

Declan McDonald - 21%
UI Designer, developer
 - Wireframes for business make booking, customer make booking, manage service types and edit specialisations
 - Created design mockups
 - User stories for business make booking, customer make booking, manage service types and edit specialisations
 - Assisted with some layout code and bug-fixing

Jasmine Ellis - 21%
Scrum master, developer
 - Facilitated meetings
 - Kept Trello up to date
 - Kept testing suite up to date with application, ran suite
 - MVC diagram
 - Layout implementation


Rob Laine-Wyllie - 24%
Tester, developer
 - Input validation on user registration page
 - Input validation on add employee page
 - General bug-fixing
 - General code abstraction to some methods